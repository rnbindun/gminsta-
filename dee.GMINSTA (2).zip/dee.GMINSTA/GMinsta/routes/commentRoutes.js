const express = require('express');
const auth = require('../middleware/auth');
const Comment = require('../models/Comment');

const router = express.Router();

// Add comment
router.post('/', auth, async (req, res) => {
  try {
    const { postId, commentText } = req.body;
    const comment = new Comment({
      postId,
      userId: req.userId,
      commentText
    });
    await comment.save();
    res.status(201).json(comment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get comments for a post
router.get('/:postId', async (req, res) => {
  try {
    const comments = await Comment.find({ postId: req.params.postId })
      .populate('userId', 'username profilePic');
    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;