const express = require('express');
const auth = require('../middleware/auth');
const Post = require('../models/Post');

const router = express.Router();

// Create post with image upload
router.post('/create', auth, (req, res) => {
  req.upload.single('image')(req, res, async (err) => {
    if (err) return res.status(400).json({ error: 'Image upload failed' });
    try {
      const { caption } = req.body;
      const image = req.file ? `/uploads/${req.file.filename}` : '';
      const post = new Post({
        userId: req.userId,
        caption,
        image
      });
      await post.save();
      res.status(201).json(post);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});

// Get feed (all posts, newest first)
router.get('/feed', auth, async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('userId', 'username profilePic')
      .sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Like a post (toggle)
router.post('/like/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const userId = req.userId;
    const liked = post.likes.includes(userId);
    const disliked = post.dislikes.includes(userId);

    if (liked) {
      post.likes = post.likes.filter(id => id.toString() !== userId);
    } else {
      post.likes.push(userId);
      if (disliked) {
        post.dislikes = post.dislikes.filter(id => id.toString() !== userId);
      }
    }
    await post.save();
    res.json({ likes: post.likes.length, dislikes: post.dislikes.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Dislike a post (toggle)
router.post('/dislike/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const userId = req.userId;
    const disliked = post.dislikes.includes(userId);
    const liked = post.likes.includes(userId);

    if (disliked) {
      post.dislikes = post.dislikes.filter(id => id.toString() !== userId);
    } else {
      post.dislikes.push(userId);
      if (liked) {
        post.likes = post.likes.filter(id => id.toString() !== userId);
      }
    }
    await post.save();
    res.json({ likes: post.likes.length, dislikes: post.dislikes.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;