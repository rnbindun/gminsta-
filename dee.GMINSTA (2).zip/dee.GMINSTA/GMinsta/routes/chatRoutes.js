const express = require('express');
const auth = require('../middleware/auth');
const Message = require('../models/Message');
const User = require('../models/User');

const router = express.Router();

// Send a message
router.post('/send', auth, async (req, res) => {
  try {
    const { receiverId, messageText } = req.body;
    const message = new Message({
      senderId: req.userId,
      receiverId,
      messageText
    });
    await message.save();
    res.status(201).json(message);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get conversation between current user and another user
router.get('/:userId', auth, async (req, res) => {
  try {
    const messages = await Message.find({
      $or: [
        { senderId: req.userId, receiverId: req.params.userId },
        { senderId: req.params.userId, receiverId: req.userId }
      ]
    }).sort({ sentAt: 1 });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all users except current (for chat list)
router.get('/users/all', auth, async (req, res) => {
  try {
    const users = await User.find({ _id: { $ne: req.userId } }).select('username profilePic');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;