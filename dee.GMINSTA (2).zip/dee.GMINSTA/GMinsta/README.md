# GMinsta – Mini Social Media Application

## Features (Level 3 Complete)
- User Registration / Login (JWT)
- Create post with image or text
- Feed (view all posts)
- Like / Dislike posts
- Comment on posts
- Chat / Messaging between users
- Profile page with user info and posts
- MongoDB integration (4 collections)

## How to Run
1. Install Node.js and MongoDB
2. Clone this folder
3. Run `npm install`
4. Create `.env` file (PORT, MONGO_URI, JWT_SECRET)
5. Run `npm start`
6. Visit `http://localhost:5000`

## API Endpoints
- POST /api/auth/register
- POST /api/auth/login
- POST /api/posts/create (with image)
- GET /api/posts/feed
- POST /api/posts/like/:id
- POST /api/posts/dislike/:id
- POST /api/comments
- GET /api/comments/:postId
- POST /api/chat/send
- GET /api/chat/:userId
- GET /api/chat/users/all