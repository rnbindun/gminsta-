if (!getToken()) window.location.href = '/views/login.html';

async function loadNotifications() {
  try {
    const [postsRes, userRes] = await Promise.all([
      authFetch('/api/posts/feed'),
      authFetch('/api/auth/me')
    ]);
    const allPosts = await postsRes.json();
    const currentUser = await userRes.json();
    const myPosts = allPosts.filter(p => p.userId._id === currentUser._id);
    const notifications = [];

    for (const post of myPosts) {
      // Likes
      for (const likerId of post.likes) {
        notifications.push({
          type: 'like',
          message: `Someone liked your post: "${post.caption.substring(0, 40)}..."`,
          time: post.createdAt
        });
      }
      // Comments
      const commentsRes = await fetch(`/api/comments/${post._id}`);
      const comments = await commentsRes.json();
      for (const cmt of comments) {
        notifications.push({
          type: 'comment',
          message: `${cmt.userId?.username || 'Someone'} commented: "${cmt.commentText}"`,
          time: cmt.createdAt
        });
      }
    }

    notifications.sort((a, b) => new Date(b.time) - new Date(a.time));
    const container = document.getElementById('notificationsList');
    if (notifications.length === 0) {
      container.innerHTML = `<div style="text-align: center; padding: 40px; background: var(--card-bg); border-radius: 24px;">✨ No notifications yet. Like and comment to see activity!</div>`;
      return;
    }
    container.innerHTML = notifications.map(notif => `
      <div style="background: var(--card-bg); border-radius: 20px; padding: 16px; display: flex; gap: 16px; border: 1px solid var(--border-light);">
        <div style="font-size: 32px;">${notif.type === 'like' ? '❤️' : '💬'}</div>
        <div style="flex:1;">
          <div>${notif.message}</div>
          <div style="font-size: 12px; color: var(--text-secondary); margin-top: 6px;">${new Date(notif.time).toLocaleString()}</div>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error(err);
    document.getElementById('notificationsList').innerHTML = `<div style="text-align: center; padding: 40px;">Error loading notifications</div>`;
  }
}
loadNotifications();