if (!getToken()) window.location.href = '/views/login.html';

let currentReceiverId = null;
let refreshInterval = null;

async function loadUsers() {
  const res = await authFetch('/api/chat/users/all');
  const users = await res.json();
  const container = document.getElementById('userList');
  if (!container) return;
  if (users.length === 0) {
    container.innerHTML = '<div style="padding: 16px; text-align: center;">No other users yet</div>';
    return;
  }
  container.innerHTML = users.map(u => `
    <div class="chat-user-item" data-id="${u._id}" data-name="${u.username}">
      <img src="${getAvatarUrl(u.username, u.profilePic)}" style="width:40px; height:40px; border-radius:50%;">
      <div><strong>${u.username}</strong></div>
    </div>
  `).join('');
  document.querySelectorAll('.chat-user-item').forEach(el => {
    el.addEventListener('click', () => {
      currentReceiverId = el.dataset.id;
      document.getElementById('chatHeader').innerHTML = `💬 Chat with ${el.dataset.name}`;
      document.getElementById('chatInputArea').style.display = 'flex';
      loadMessages(currentReceiverId);
      if (refreshInterval) clearInterval(refreshInterval);
      refreshInterval = setInterval(() => {
        if (currentReceiverId) loadMessages(currentReceiverId, true);
      }, 3000);
    });
  });
}

async function loadMessages(receiverId, silent = false) {
  const res = await authFetch(`/api/chat/${receiverId}`);
  const msgs = await res.json();
  const container = document.getElementById('messagesList');
  if (!container) return;
  const currentUserId = getUserId();
  if (msgs.length === 0 && !silent) {
    container.innerHTML = '<div style="text-align:center; padding:40px;">✨ No messages yet. Say hi!</div>';
    return;
  }
  container.innerHTML = msgs.map(m => `
    <div style="display:flex; justify-content: ${m.senderId === currentUserId ? 'flex-end' : 'flex-start'};">
      <div class="${m.senderId === currentUserId ? 'message-bubble-sent' : 'message-bubble-received'}">
        ${escapeHtml(m.messageText)}
      </div>
    </div>
  `).join('');
  container.scrollTop = container.scrollHeight;
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

document.getElementById('sendMsgBtn')?.addEventListener('click', async () => {
  if (!currentReceiverId) return alert('Select a user first');
  const input = document.getElementById('messageInput');
  const msg = input.value.trim();
  if (!msg) return;
  await authFetch('/api/chat/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ receiverId: currentReceiverId, messageText: msg })
  });
  input.value = '';
  loadMessages(currentReceiverId);
});
document.getElementById('messageInput')?.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') document.getElementById('sendMsgBtn')?.click();
});
window.addEventListener('beforeunload', () => {
  if (refreshInterval) clearInterval(refreshInterval);
});
loadUsers();