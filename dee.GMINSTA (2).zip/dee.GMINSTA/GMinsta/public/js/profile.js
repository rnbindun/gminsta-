if (!getToken()) window.location.href = '/views/login.html';

async function loadProfile() {
  const res = await authFetch('/api/auth/me');
  const user = await res.json();
  const avatarUrl = getAvatarUrl(user.username, user.profilePic);
  const profileDiv = document.getElementById('profileInfo');
  profileDiv.innerHTML = `
    <div class="profile-header">
      <img src="${avatarUrl}" class="profile-avatar">
      <div>
        <h2>${user.username}</h2>
        <div class="profile-stats">
          <div><strong>${user.postsCount || 0}</strong> posts</div>
          <div><strong>${user.followers?.length || 0}</strong> followers</div>
          <div><strong>${user.following?.length || 0}</strong> following</div>
        </div>
        <p>${user.bio || '✨ GMinsta user'}</p>
      </div>
    </div>
  `;
  const postsRes = await authFetch('/api/posts/feed');
  const allPosts = await postsRes.json();
  const myPosts = allPosts.filter(p => p.userId._id === user._id);
  const grid = document.getElementById('userPostsGrid');
  grid.innerHTML = myPosts.map(p => `
    <div class="grid-post">
      <img src="${p.image || 'https://via.placeholder.com/300?text=No+Image'}" alt="post">
    </div>
  `).join('');
}
loadProfile();