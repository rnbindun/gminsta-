if (!getToken()) window.location.href = '/views/login.html';

let allPosts = [];

async function loadExplore() {
  const res = await authFetch('/api/posts/feed');
  allPosts = await res.json();
  renderGrid(allPosts);
}
function renderGrid(posts) {
  const grid = document.getElementById('exploreGrid');
  grid.innerHTML = posts.map(post => `
    <div class="grid-post" data-username="${post.userId.username}">
      <img src="${post.image || 'https://via.placeholder.com/300?text=GMinsta'}" alt="post">
    </div>
  `).join('');
}
document.getElementById('searchInput')?.addEventListener('input', (e) => {
  const term = e.target.value.toLowerCase();
  const filtered = allPosts.filter(p => p.userId.username.toLowerCase().includes(term));
  renderGrid(filtered);
});
loadExplore();