if (!getToken()) window.location.href = '/views/login.html';

const feedContainer = document.getElementById('feedContainer');
const createModal = document.getElementById('createModal');
const createPostBtnBottom = document.getElementById('createPostBtnBottom');
const closeModal = document.getElementById('closeModal');
const submitPost = document.getElementById('submitPost');
const postCaption = document.getElementById('postCaption');
const postImage = document.getElementById('postImage');
const imagePreview = document.getElementById('imagePreview');

createPostBtnBottom?.addEventListener('click', (e) => {
  e.preventDefault();
  createModal.style.display = 'flex';
});
closeModal?.addEventListener('click', () => {
  createModal.style.display = 'none';
  postCaption.value = '';
  postImage.value = '';
  imagePreview.style.display = 'none';
});
postImage?.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (ev) => {
      imagePreview.src = ev.target.result;
      imagePreview.style.display = 'block';
    };
    reader.readAsDataURL(file);
  }
});
submitPost?.addEventListener('click', async () => {
  const formData = new FormData();
  formData.append('caption', postCaption.value);
  if (postImage.files[0]) formData.append('image', postImage.files[0]);
  const res = await authFetch('/api/posts/create', { method: 'POST', body: formData });
  if (res.ok) {
    createModal.style.display = 'none';
    postCaption.value = '';
    postImage.value = '';
    imagePreview.style.display = 'none';
    loadFeed();
  } else alert('Failed to create post');
});

async function loadFeed() {
  const res = await authFetch('/api/posts/feed');
  const posts = await res.json();
  feedContainer.innerHTML = '';
  const currentUserId = getUserId();
  for (let post of posts) {
    const isLiked = post.likes.includes(currentUserId);
    const avatarUrl = getAvatarUrl(post.userId.username, post.userId.profilePic);
    const postDiv = document.createElement('div');
    postDiv.className = 'post-card';
    postDiv.innerHTML = `
      <div class="post-header">
        <img class="avatar" src="${avatarUrl}" alt="avatar">
        <span class="post-username">${post.userId.username}</span>
      </div>
      ${post.image ? `<img class="post-image" src="${post.image}" alt="post">` : ''}
      <div class="post-actions">
        <div class="action-buttons">
          <button class="like-btn ${isLiked ? 'liked' : ''}" data-id="${post._id}"><i class="fas fa-heart"></i></button>
          <button class="dislike-btn" data-id="${post._id}"><i class="fas fa-thumbs-down"></i></button>
          <button class="comment-toggle" data-id="${post._id}"><i class="fas fa-comment"></i></button>
        </div>
        <button class="save-btn"><i class="fas fa-bookmark"></i></button>
      </div>
      <div class="post-caption"><strong>${post.userId.username}</strong> ${post.caption}</div>
      <div class="post-time">${new Date(post.createdAt).toLocaleDateString()}</div>
      <div class="comments-section" id="comments-${post._id}" style="display: none; padding: 12px 16px;">
        <div id="commentList-${post._id}" class="comment-list"></div>
        <div class="comment-input-area">
          <input type="text" id="commentInput-${post._id}" class="comment-input" placeholder="Add a comment...">
          <button class="comment-submit" data-id="${post._id}">Post</button>
        </div>
      </div>
    `;
    feedContainer.appendChild(postDiv);
  }
  attachEvents();
}

function attachEvents() {
  document.querySelectorAll('.like-btn').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.id;
      await authFetch(`/api/posts/like/${id}`, { method: 'POST' });
      loadFeed();
    };
  });
  document.querySelectorAll('.dislike-btn').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.id;
      await authFetch(`/api/posts/dislike/${id}`, { method: 'POST' });
      loadFeed();
    };
  });
  document.querySelectorAll('.comment-toggle').forEach(btn => {
    btn.onclick = () => {
      const id = btn.dataset.id;
      const sec = document.getElementById(`comments-${id}`);
      sec.style.display = sec.style.display === 'none' ? 'block' : 'none';
      if (sec.style.display === 'block') loadComments(id);
    };
  });
  document.querySelectorAll('.comment-submit').forEach(btn => {
    btn.onclick = async () => {
      const postId = btn.dataset.id;
      const input = document.getElementById(`commentInput-${postId}`);
      const text = input.value.trim();
      if (!text) return;
      await authFetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId, commentText: text })
      });
      input.value = '';
      loadComments(postId);
    };
  });
}

async function loadComments(postId) {
  const res = await fetch(`/api/comments/${postId}`);
  const comments = await res.json();
  const container = document.getElementById(`commentList-${postId}`);
  if (container) {
    container.innerHTML = comments.map(c => `<div class="comment-item"><span class="comment-username">${c.userId?.username}</span> ${c.commentText}</div>`).join('');
  }
}
loadFeed();