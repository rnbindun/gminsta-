const API_BASE = '/api';

function getToken() { return localStorage.getItem('token'); }
function getUserId() { return localStorage.getItem('userId'); }
function getUsername() { return localStorage.getItem('username'); }

function authFetch(url, options = {}) {
  const token = getToken();
  if (token) {
    options.headers = {
      ...options.headers,
      'Authorization': `Bearer ${token}`
    };
  }
  return fetch(url, options);
}

function logout() {
  localStorage.clear();
  window.location.href = '/views/login.html';
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('logoutBtn');
  if (btn) btn.addEventListener('click', logout);
});

function getAvatarUrl(username, pic) {
  if (pic && pic.startsWith('http')) return pic;
  return `https://ui-avatars.com/api/?background=B877F5&color=fff&name=${encodeURIComponent(username)}`;
}